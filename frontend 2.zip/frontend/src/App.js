import logo from './logo.svg';
import './App.css';
import Home from './screens/home';
import AskQuestion from './screens/ask-question';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import NavBar from './common/navbar';
import Answer from './screens/answer';


export default function App() {
  return (
    <>   <NavBar />
    <br></br>
    <br></br>
    <br></br>
    <BrowserRouter>
      <Routes>
     
        <Route path="/" element={<Home />} />
          <Route index element={<Home />} />
          <Route path="ask-question" element={<AskQuestion />} />
          <Route path="answer/:id" element={<Answer />} />

          {/* <Route path="contact" element={<Contact />} /> */}
          <Route path="*" element={<AskQuestion />} />
       </Routes>
    </BrowserRouter>
    </>
  );
}


 