import Sidebar from "../../common/sidebar";
import { FaUser } from "react-icons/fa";

import "./home.css"
import '../../../node_modules/react-draft-wysiwyg/dist/react-draft-wysiwyg.css'
import CardQuestion from "../../common/questionCard";

const Home = () => {


    //TODO1 we need to remove center
    return (<div>
         <center>
            <div style={{ display: "flex", flexDirection: 'row', width: '70%', alignItems: 'flex-start', textAlign: 'start' }}>
                <Sidebar />
                <div style={{
                    flex: 1,
                    padding: '10px 10px',
                    display: 'flex',
                    flexDirection: 'column'
                }}>
                    <h1 style={{
                        fontSize: '25px',
                        color: 'grey'
                    }}>
                        All Question
                    </h1>
                    <div style={{
                        display: 'flex',
                        flexDirection: 'column',
                    }}>
                        24,00,000,00 questions
                    </div>
                    <hr />

                    {/* Cards  */}
                    <CardQuestion />




                </div>
            </div>
        </center>
    </div>
    )
}

export default Home;