import Sidebar from "../../common/sidebar";
import { FaUser } from "react-icons/fa";

// import "./home.css"
import NavBar from "../../common/navbar";

import { Editor } from 'react-draft-wysiwyg';
import '../../../node_modules/react-draft-wysiwyg/dist/react-draft-wysiwyg.css'

const AskQuestion = () => {


    //TODO1 we need to remove center
    return (<div>
        <center>
            <div style={{ display: "flex", flexDirection: 'row', width: '70%', alignItems: 'flex-start', textAlign: 'start' }}>
                <Sidebar />
                <div style={{
                    flex: 1,
                    padding: '10px 10px',
                    display: 'flex',
                    flexDirection: 'column'
                }}>
                    <input style={{
                        padding: '10px 10px', color: 'black',
                        fontSize: '20px',
                        border: '1px solid orange'
                    }} placeholder="Ask Question...." />
                    <div style={{
                        display: 'flex',
                        flexDirection: 'column',
                    }}>
                    </div>
                    <hr />
                    <Editor placeholder="Describe you problem in detail" wrapperStyle={{
                        border: '1px solid #e2e2e2',
                        padding: '10px 10px',
                        tabSize: '10'
                    }} />
                    <input style={{
                        padding: '10px 10px',
                        color: 'black',
                        fontSize: '16px',
                        marginTop: '10px',
                        border: '1px solid #e2e2e2'
                    }} placeholder="Add tags(Comma seprated)" />
                    <input style={{
                        padding: '10px 10px',
                        color: 'black',
                        fontSize: '16px',
                        marginTop: '10px',
                        border: '1px solid #e2e2e2'
                    }} placeholder="Add Related Department Name" />
                    <button style={{
                        width:'200px',
                        marginTop:'10px',
                        color:'white',
                        backgroundColor:'#1b75d0',
                        border:'none',
                        padding:'10px 10px',
                        fontSize:'16px'
                    }}>Publish</button>

                </div>
            </div>
        </center>
    </div>
    )
}

export default AskQuestion;