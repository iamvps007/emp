import Sidebar from "../../common/sidebar";
import { FaUser } from "react-icons/fa";

// import "./home.css"
import NavBar from "../../common/navbar";

import { Editor } from 'react-draft-wysiwyg';
import '../../../node_modules/react-draft-wysiwyg/dist/react-draft-wysiwyg.css'
import AnswerCard from "../../common/answerCard";

const Answer = () => {


    //TODO1 we need to remove center
    return (<div>
        <center>
            <div style={{ display: "flex", flexDirection: 'row', width: '70%', alignItems: 'flex-start', textAlign: 'start' }}>
                <Sidebar />
                <div style={{
                    flex: 1,
                    padding: '10px 10px',
                    display: 'flex',
                    flexDirection: 'column'
                }}>
                    <h1 style={{
                        fontSize: '25px',
                        color: 'black'
                    }}>
                        <span style={{
                            color:'grey',
                            fontSize:'20px'
                        }}>Q</span> How to get free sex?
                    </h1>
                    <div style={{
                        display: 'flex',
                        flexDirection: 'column',
                    }}>
                    </div>
                    <p style={{margin:'0px', fontSize:'14px', color:'grey'}}>Asked by Kaushal Kumar 20 Year Ago</p>
                    <hr />
                    <p style={{
                        margin:'0px'
                    }}>
                    Don't write any Interceptors, Filters, Components, Aspects, etc., this is a very common problem and has been solved many times over.
<br></br><br></br>
Spring Boot has a modules called Actuator, which provides HTTP request logging out of the box. There's an endpoint mapped to /trace (SB1.x) or /actuator/httptrace (SB2.0+) which will show you last 100 HTTP requests. You can customize it to log each request, or write to a DB.
<br></br><br></br>
To get the endpoints you want, you'll need the spring-boot-starter-actuator dependency, and also to "whitelist" the endpoints you're looking for, and possibly setup or disable security for it.
<br></br><br></br>
Also, where will this application run? Will you be using a PaaS? Hosting providers, Heroku for example, provide request logging as part of their service and you don't need to do any coding whatsoever then.
                    </p>
                    <hr />
                    <div id="tag" style={{
                    display: 'flex',
                    flexDirection: 'row'
                }}>
                    <div style={{
                        backgroundColor: '#e2e2e2',
                        padding: '5px 5px',
                        color: '10px',
                        margin: '5px 0px',
                        fontSize: '12px'
                    }}>
                        Money Out
                    </div>
                    <div style={{
                        backgroundColor: '#e2e2e2',
                        padding: '5px 5px',
                        color: '10px',
                        margin: '5px 5px',
                        fontSize: '12px'
                    }}>
                        Money Out
                    </div>
                </div>
                <hr />
                    <div style={{
                        display:'flex',
                        flexDirection:'row'
                    }}>
                    <h1 style={{
                        fontSize: '25px',
                        color: 'black',
                        margin:'0px',
                        padding:'0px',
                        flex:1
                    }}>
                        <span style={{
                            color:'grey',
                            fontSize:'20px'
                        }}>Answer</span>
                    </h1>
                    <button style={{
                        alignItems:'end',
                        alignContent:'end',
                        marginTop:'10px',
                        color:'white',
                        backgroundColor:'#1b75d0',
                        border:'none',
                        padding:'4px',
                        fontSize:'16px'
                    }}>Submit Your Answer</button>
                    </div>
                    <br></br>
                    <AnswerCard/>

                    <AnswerCard/>
                    <AnswerCard/>
                    <AnswerCard/>
                    <div style={{
                        backgroundColor:'yellowgreen',
                        color:'white',
                        padding:'10px 10px'
                    }}> 
                    Do you know how to solve this Answer this question to help you peer
                    </div>
                    <br></br>
                    
                    <Editor wrapperStyle={{
                        border:'1px solid grey'
                    }} />
                    
                    <button style={{
                        width:'250px',
                        alignItems:'end',
                        alignContent:'end',
                        marginTop:'10px',
                        color:'white',
                        backgroundColor:'#1b75d0',
                        border:'none',
                        padding:'4px',
                        fontSize:'16px'
                    }}>Submit Your Answer</button>
                     
                    <br></br>
                    <br></br>

                </div>
            </div>
        </center>
    </div>
    )
}

export default Answer;