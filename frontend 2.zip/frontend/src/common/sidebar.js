
import { FaHome, FaQuestion, FaTag } from "react-icons/fa";
import { Link } from "react-router-dom";


const Sidebar = () => {

    return(
    <div style={{
        flex:0.2, 
        width:'100px',
        height:'100vh',
        border:'1px solid #e2e2e2',
        display:'flex',
        flexDirection: 'column',    
    }}>
         <Link style={{
            textDecoration:'none'
        }} to={"/"}>
        <div style={{
            padding:'10px 10px',
            padding:'12px 12px',
            color:'black',
            fontWeight:'400',
            fontSize:'18px',
            display:'flex',
            flexDirection:'row'
        }}>
            <FaHome  size={20}  style={{
                paddingRight:'10px',
                paddingTop:'2px'
            }}/>Home
        </div>
        </Link>
        <Link style={{
            textDecoration:'none'
        }} to={"/ask-question"}>
        <div style={{
            padding:'12px 12px',
            color:'black',
            fontWeight:'400',
            fontSize:'18px',
            display:'flex',
            flexDirection:'row',
         }}>
            <FaQuestion  size={20}  style={{
                paddingRight:'10px',
                paddingTop:'2px'
            }}/>Ask Question
        </div>
        </Link>
        <hr></hr>
        <p style={{
            paddingLeft:'10px',
            marginTop:'0px',
            color:'grey',
            fontWeight:'bolder'
        }}>Popular Tags</p>
        <div style={{
            padding:'12px 12px',
            color:'black',
            fontWeight:'400',
            fontSize:'18px',
            display:'flex',
            flexDirection:'row',
        }}>
            <FaTag  size={15}  style={{
                paddingRight:'10px',
                paddingTop:'3px'
            }}/>MoneyOut
        </div>
        <div style={{
            padding:'12px 12px',
            color:'black',
            fontWeight:'400',
            fontSize:'18px',
            display:'flex',
            flexDirection:'row',
        }}>
            <FaTag  size={15}  style={{
                paddingRight:'10px',
                paddingTop:'3px'
            }}/>MoneyOut
        </div>
        <div style={{
            padding:'12px 12px',
            color:'black',
            fontWeight:'400',
            fontSize:'18px',
            display:'flex',
            flexDirection:'row',
        }}>
            <FaTag  size={15}  style={{
                paddingRight:'10px',
                paddingTop:'3px'
            }}/>MoneyOut
        </div>

        

    </div>
    )
}

export default Sidebar;