import { FaUserAlt } from "react-icons/fa";

const CardQuestion = () => {
    return(
        <>
        <div style={{
            display: 'flex',
            flexDirection: 'row',
        }}>
            <div style={{
                display: 'flex',
                flexDirection: 'column',
                width: '150px',
                alignItems: 'end'
            }}>
                <div style={{
                    fontSize: '14px',
                    color: '#7e7e7e',
                    fontWeight: '600',
                    padding: '5px 5px'
                }}>1 Votes</div>
                <div style={{
                    fontSize: '14px',
                    color: '#7e7e7e',
                    fontWeight: '600',
                    padding: '5px 5px'
                }}>1 Answer</div>
                <div style={{
                    fontSize: '14px',
                    color: '#7e7e7e',
                    fontWeight: '600',
                    padding: '5px 5px'
                }}>1 Votes</div>
            </div>
            <div id="question_part" style={{
                marginLeft: '10px'
            }}>
                <div style={{
                    color: '#1b75d0',
                    padding: '5px 5px',
                    fontWeight: 'bold'
                }}>
                    How to get data based on dropdown selection</div>
                <div style={{
                    color:'grey'
                }}>lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg.... </div>
                <div id="tag" style={{
                    display: 'flex',
                    flexDirection: 'row'
                }}>
                    <div style={{
                        backgroundColor: '#e2e2e2',
                        padding: '5px 5px',
                        color: '10px',
                        margin: '5px 0px',
                        fontSize: '12px'
                    }}>
                        Money Out
                    </div>
                    <div style={{
                        backgroundColor: '#e2e2e2',
                        padding: '5px 5px',
                        color: '10px',
                        margin: '5px 5px',
                        fontSize: '12px'
                    }}>
                        Money Out
                    </div>
                </div>
                <div id="author" style={{
                    color: 'black',
                    display: 'flex',
                    flexDirection: 'row',
                    alignContent: 'end'
                }}>
                    <div style={{
                        fontWeight: '400',
                        textAlign: 'end',
                        marginRight: '10px',
                        textDecoration:'underline'
                    }}> kaushal Kumar
                        <span style={{
                            color: 'grey',
                            fontWeight: '500',
                            marginLeft: '5px',
                            textDecoration:'none'
                        }}>
                            Asked 1 min ago
                        </span>
                    </div>

                </div>

            </div>

        </div>

        <hr></hr>
        </>
    )
}

export default CardQuestion;