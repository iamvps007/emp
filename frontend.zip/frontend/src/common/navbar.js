const NavBar = () => {


    return(
        <div style={{
            border:'1px solid #e2e2e2',
        }}>
        <center>
    <div style={{
        display:'flex',
        flexDirection:'row',
        width:'70%',
        padding:'10px 10px',
       
        
    }}>
        <img src="https://www.empower.com/themes/custom/wealth_management_v2/images/branding/logo-new-alt.svg" width={"200"} />
         <input type="text" style={{
            marginLeft:'10px',
            border:'1px solid #e2e2e2',
            width:'60%',
            padding:'10px',
            
         }} placeholder="Ask me anything " />
        

    </div>
    </center>
    </div>)
}

export default NavBar;