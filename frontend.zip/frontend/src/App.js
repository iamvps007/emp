import logo from './logo.svg';
import './App.css';
import Home from './screens/home';
import AskQuestion from './screens/ask-question';

function App() {
  return (
    <AskQuestion />
  );
}

export default App;
