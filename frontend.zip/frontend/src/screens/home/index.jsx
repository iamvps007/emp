import Sidebar from "../../common/sidebar";
import { FaUser } from "react-icons/fa";

import "./home.css"
import NavBar from "../../common/navbar";

import { Editor } from 'react-draft-wysiwyg';
import '../../../node_modules/react-draft-wysiwyg/dist/react-draft-wysiwyg.css'

const Home = () => {


    //TODO1 we need to remove center
    return (<div>
        <NavBar></NavBar>
        <center>
            <div style={{ display: "flex", flexDirection: 'row', width: '70%', alignItems: 'flex-start', textAlign: 'start' }}>
                <Sidebar />
                <div style={{
                    flex: 1,
                    padding: '10px 10px',
                    display: 'flex',
                    flexDirection: 'column'
                }}>
                    <h1 style={{
                        fontSize: '25px',
                        color: 'grey'
                    }}>
                        All Question
                    </h1>
                    <div style={{
                        display: 'flex',
                        flexDirection: 'column',
                    }}>
                        24,00,000,00 questions
                    </div>
                    <hr />

                    {/* Cards  */}
                    <div style={{
                        display: 'flex',
                        flexDirection: 'row',
                    }}>
                        <div style={{
                            display: 'flex',
                            flexDirection: 'column',
                            width: '150px',
                            alignItems: 'end'
                        }}>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Votes</div>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Answer</div>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Votes</div>
                        </div>
                        <div id="question_part" style={{
                            marginLeft: '10px'
                        }}>
                            <div style={{
                                color: '#03a9f4',
                                padding: '5px 5px',
                                fontWeight: 'bold'
                            }}>
                                How to get data based on dropdown selection</div>
                            <div>lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg</div>
                            <div id="tag" style={{
                                display: 'flex',
                                flexDirection: 'row'
                            }}>
                                <div style={{
                                    backgroundColor: '#e2e2e2',
                                    padding: '5px 5px',
                                    color: '10px',
                                    margin: '5px 0px',
                                    fontSize: '12px'
                                }}>
                                    Money Out
                                </div>
                                <div style={{
                                    backgroundColor: '#e2e2e2',
                                    padding: '5px 5px',
                                    color: '10px',
                                    margin: '5px 5px',
                                    fontSize: '12px'
                                }}>
                                    Money Out
                                </div>
                            </div>
                            <div id="author" style={{
                                color: 'black',
                                display: 'flex',
                                flexDirection: 'row',
                                alignContent: 'end'
                            }}>
                                <div style={{
                                    fontWeight: '800',
                                    textAlign: 'end',
                                    marginRight: '10px'
                                }}><FaUser width={"5"}></FaUser> Kaushal Kumar
                                    <span style={{
                                        color: 'grey',
                                        fontWeight: '500',
                                        marginLeft: '5px'
                                    }}>
                                        Asked 1 min ago
                                    </span>
                                </div>

                            </div>

                        </div>

                    </div>

                    <hr></hr>
                    <div style={{
                        display: 'flex',
                        flexDirection: 'row',
                    }}>
                        <div style={{
                            display: 'flex',
                            flexDirection: 'column',
                            width: '150px',
                            alignItems: 'end'
                        }}>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Votes</div>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Answer</div>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Votes</div>
                        </div>
                        <div id="question_part" style={{
                            marginLeft: '10px'
                        }}>
                            <div style={{
                                color: '#03a9f4',
                                padding: '5px 5px',
                                fontWeight: 'bold'
                            }}>
                                How to get data based on dropdown selection</div>
                            <div>lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg</div>
                            <div id="tag" style={{
                                display: 'flex',
                                flexDirection: 'row'
                            }}>
                                <div style={{
                                    backgroundColor: '#e2e2e2',
                                    padding: '5px 5px',
                                    color: '10px',
                                    margin: '5px 0px',
                                    fontSize: '12px'
                                }}>
                                    Money Out
                                </div>
                                <div style={{
                                    backgroundColor: '#e2e2e2',
                                    padding: '5px 5px',
                                    color: '10px',
                                    margin: '5px 5px',
                                    fontSize: '12px'
                                }}>
                                    Money Out
                                </div>
                            </div>
                            <div id="author" style={{
                                color: 'black',
                                display: 'flex',
                                flexDirection: 'row',
                                alignContent: 'end'
                            }}>
                                <div style={{
                                    fontWeight: '800',
                                    textAlign: 'end',
                                    marginRight: '10px'
                                }}><FaUser width={"5"}></FaUser> Kaushal Kumar
                                    <span style={{
                                        color: 'grey',
                                        fontWeight: '500',
                                        marginLeft: '5px'
                                    }}>
                                        Asked 1 min ago
                                    </span>
                                </div>

                            </div>

                        </div>

                    </div>
                    <hr></hr>
                    <div style={{
                        display: 'flex',
                        flexDirection: 'row',
                    }}>
                        <div style={{
                            display: 'flex',
                            flexDirection: 'column',
                            width: '150px',
                            alignItems: 'end'
                        }}>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Votes</div>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Answer</div>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Votes</div>
                        </div>
                        <div id="question_part" style={{
                            marginLeft: '10px'
                        }}>
                            <div style={{
                                color: '#03a9f4',
                                padding: '5px 5px',
                                fontWeight: 'bold'
                            }}>
                                How to get data based on dropdown selection</div>
                            <div>lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg</div>
                            <div id="tag" style={{
                                display: 'flex',
                                flexDirection: 'row'
                            }}>
                                <div style={{
                                    backgroundColor: '#e2e2e2',
                                    padding: '5px 5px',
                                    color: '10px',
                                    margin: '5px 0px',
                                    fontSize: '12px'
                                }}>
                                    Money Out
                                </div>
                                <div style={{
                                    backgroundColor: '#e2e2e2',
                                    padding: '5px 5px',
                                    color: '10px',
                                    margin: '5px 5px',
                                    fontSize: '12px'
                                }}>
                                    Money Out
                                </div>
                            </div>
                            <div id="author" style={{
                                color: 'black',
                                display: 'flex',
                                flexDirection: 'row',
                                alignContent: 'end'
                            }}>
                                <div style={{
                                    fontWeight: '800',
                                    textAlign: 'end',
                                    marginRight: '10px'
                                }}><FaUser width={"5"}></FaUser> Kaushal Kumar
                                    <span style={{
                                        color: 'grey',
                                        fontWeight: '500',
                                        marginLeft: '5px'
                                    }}>
                                        Asked 1 min ago
                                    </span>
                                </div>

                            </div>

                        </div>

                    </div>
                    <hr></hr>
                    <div style={{
                        display: 'flex',
                        flexDirection: 'row',
                    }}>
                        <div style={{
                            display: 'flex',
                            flexDirection: 'column',
                            width: '150px',
                            alignItems: 'end'
                        }}>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Votes</div>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Answer</div>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Votes</div>
                        </div>
                        <div id="question_part" style={{
                            marginLeft: '10px'
                        }}>
                            <div style={{
                                color: '#03a9f4',
                                padding: '5px 5px',
                                fontWeight: 'bold'
                            }}>
                                How to get data based on dropdown selection</div>
                            <div>lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg</div>
                            <div id="tag" style={{
                                display: 'flex',
                                flexDirection: 'row'
                            }}>
                                <div style={{
                                    backgroundColor: '#e2e2e2',
                                    padding: '5px 5px',
                                    color: '10px',
                                    margin: '5px 0px',
                                    fontSize: '12px'
                                }}>
                                    Money Out
                                </div>
                                <div style={{
                                    backgroundColor: '#e2e2e2',
                                    padding: '5px 5px',
                                    color: '10px',
                                    margin: '5px 5px',
                                    fontSize: '12px'
                                }}>
                                    Money Out
                                </div>
                            </div>
                            <div id="author" style={{
                                color: 'black',
                                display: 'flex',
                                flexDirection: 'row',
                                alignContent: 'end'
                            }}>
                                <div style={{
                                    fontWeight: '800',
                                    textAlign: 'end',
                                    marginRight: '10px'
                                }}><FaUser width={"5"}></FaUser> Kaushal Kumar
                                    <span style={{
                                        color: 'grey',
                                        fontWeight: '500',
                                        marginLeft: '5px'
                                    }}>
                                        Asked 1 min ago
                                    </span>
                                </div>

                            </div>

                        </div>

                    </div>
                    <hr></hr>
                    <div style={{
                        display: 'flex',
                        flexDirection: 'row',
                    }}>
                        <div style={{
                            display: 'flex',
                            flexDirection: 'column',
                            width: '150px',
                            alignItems: 'end'
                        }}>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Votes</div>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Answer</div>
                            <div style={{
                                fontSize: '14px',
                                color: '#7e7e7e',
                                fontWeight: '600',
                                padding: '5px 5px'
                            }}>1 Votes</div>
                        </div>
                        <div id="question_part" style={{
                            marginLeft: '10px'
                        }}>
                            <div style={{
                                color: '#03a9f4',
                                padding: '5px 5px',
                                fontWeight: 'bold'
                            }}>
                                How to get data based on dropdown selection</div>
                            <div>lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg lapsa ashdg ashjdb hjsad hjasd hjsabd hjasbdjhb ashdjhg</div>
                            <div id="tag" style={{
                                display: 'flex',
                                flexDirection: 'row'
                            }}>
                                <div style={{
                                    backgroundColor: '#e2e2e2',
                                    padding: '5px 5px',
                                    color: '10px',
                                    margin: '5px 0px',
                                    fontSize: '12px'
                                }}>
                                    Money Out
                                </div>
                                <div style={{
                                    backgroundColor: '#e2e2e2',
                                    padding: '5px 5px',
                                    color: '10px',
                                    margin: '5px 5px',
                                    fontSize: '12px'
                                }}>
                                    Money Out
                                </div>
                            </div>
                            <div id="author" style={{
                                color: 'black',
                                display: 'flex',
                                flexDirection: 'row',
                                alignContent: 'end'
                            }}>
                                <div style={{
                                    fontWeight: '800',
                                    textAlign: 'end',
                                    marginRight: '10px'
                                }}><FaUser width={"5"}></FaUser> Kaushal Kumar
                                    <span style={{
                                        color: 'grey',
                                        fontWeight: '500',
                                        marginLeft: '5px'
                                    }}>
                                        Asked 1 min ago
                                    </span>
                                </div>

                            </div>

                        </div>

                    </div>
                    <hr></hr>




                </div>
            </div>
        </center>
    </div>
    )
}

export default Home;